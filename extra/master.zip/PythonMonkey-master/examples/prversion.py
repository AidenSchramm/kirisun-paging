import sys
print(sys.version_info)
# Jython --> 2.5.3
